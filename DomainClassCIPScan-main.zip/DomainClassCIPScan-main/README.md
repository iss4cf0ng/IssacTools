# Domain  Class C IP Scan
C段域名反查工具

！！！   
工具重寫版本 [SiteHunter](https://github.com/malbuffer4pt/SiteHunter)     
！！！    

前言:
網上有很多用fofa, shadon, zoomeye做的掃描工具，
但是我找不到可以使用的GUI C段掃描工具，大部份都是Console Application或API已經失效，
所以寫了個簡單的工具

目的:
信息收集是滲透測試中重要的過程，對於大型機關，企業，
例如大學，都會有很多C段和B段伺服器，找到越多域名，旁注成功的機會就會高很多。

![D!](1.png)

聲名:
工具只限用於合法滲透測試，請勿用於非法用途，一切後果與本人無關。

V1.0
幾年前寫的，
目前只有同服查詢和C段查詢，也懶得修BUG
之後會再加強和修BUG
