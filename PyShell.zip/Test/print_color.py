import os

from cv2 import line

os.system("color")
a = "\033[92m" + "green" + "\033[0m"
f = open('b.txt', 'r')
lines = f.readlines()
for i in lines:
    print(eval(i))

f.close()