import socket

clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientSocket.connect(('140.112.241.50', 5000))

fp = open('client.py', 'rb')

while True:
    data = fp.read(16)
    
    if not data:
        break
    clientSocket.send(data)
fp.close()
clientSocket.close()