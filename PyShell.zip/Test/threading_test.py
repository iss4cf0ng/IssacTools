import time
import threading

class WorkerThread(threading.Thread):
    
    def __init__(self, count):
        super().__init__()
        self.count = count
        
    def run(self):
        for i in range(self.count):
            print(f"{threading.current_thread().name}: {i}")
            time.sleep(1)

COUNT = 5

# Create another thread & run it
new_thread = WorkerThread(COUNT)
new_thread.start()

# Count from 0 to COUNT
for i in range(COUNT):
    print(f"{threading.current_thread().name}: {i}")
    time.sleep(1)
    
# Wait for new_thread completing its task
new_thread.join()

print("======")