#server
import socket

serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serverSocket.bind(('140.112.241.50', 5000))
serverSocket.listen()

f = open('new_py' + '.py', 'wb')

while True:
    conn, addr = serverSocket.accept()
    print('connect from:', addr)
    
    while True:
        data = conn.recv(2048)
        while(data):
            f.write(data)
            data = conn.recv(2048)
        conn.close()
        break
    conn.close()
serverSocket.close()