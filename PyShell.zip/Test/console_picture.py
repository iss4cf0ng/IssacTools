import os
from pathlib import Path
import sys

os.system("color")
local_path = str(Path().absolute())
file_path = local_path + "\\ConsolePicture"
file_list = os.listdir(file_path)
f= open(file_path + "\\" + file_list[2], 'r')
sys.stdout.write(f.read())
f.close()