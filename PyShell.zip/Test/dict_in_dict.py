d1 = {
    "a1" : 1,
    "b1" : 2
}

d2 = {
    "a2" : 1,
    "b2" : 2
}

d1.append(d2)
print(d1)