from pynput import keyboard

def keyboard_record():
    char=[]
    keyboard.hook(lambda e: char.append())
    keyboard.wait('Ctrl')
    print(char)
    
keyboard_record()