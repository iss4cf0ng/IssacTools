def a():
    def b():
        print("b")
        
    def c():
        print("C")
        
    b()
        
a()