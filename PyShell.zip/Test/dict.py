import subprocess

output = subprocess.check_output('ipconfig', shell=True)
print(output.decode('Big5'))