import socket
from _thread import *

serverSocket = socket.socket()
host = '127.0.0.1'
port = 5000
threadCount = 0

try:
    serverSocket.bind((host, port))
except:
    print()
    
serverSocket.listen(5)

def threaded_client(connection):
    while True:
        data = connection.recv(2048)
        reply = "Server says" + data.encode('utf-8')
        if not data:
            break
        connection.sendall(str.encode(reply))
    connection.close(())

while True:
    client, address = serverSocket.accept()
    print("Connected to:", address[0] + ':' + str(address[1]))
    start_new_thread(threaded_client, (client, ))
    threadCount += 1
serverSocket.close()
    