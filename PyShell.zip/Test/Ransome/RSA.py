import math
import random

p = 11
q = 13
N = p * q
L = math.lcm(p - 1, q - 1)
rand = 53 #random.randrange(1, L)
print(rand)
for i in range(2, N):
    print('%d * %d mod %d = %d' % (rand, i, L, N * i % L))