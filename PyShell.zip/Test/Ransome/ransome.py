from msilib.schema import File
from pathlib import Path
import tarfile
from cryptography.fernet import Fernet
import os

key = Fernet.generate_key()
print(key)
target_file = 'NukeDOS v1.0.exe'
extension = os.path.splitext(target_file)[1]
encrypted_filename = target_file.replace(extension, '.pyshell')

with open('filekey.key', 'wb') as filekey:
    filekey.write(key)

with open('filekey.key', 'rb') as filekey:
    key = filekey.read()
    
fernet = Fernet(key)

with open(target_file, 'rb') as file:
    original = file.read()
    
encrypted = fernet.encrypt(original)

with open(target_file, 'wb') as encrypt_file:
    encrypt_file.write(encrypted)
    
os.rename(target_file, encrypted_filename)
os.system("pause")

decrypted = fernet.decrypt(encrypted)

os.rename(encrypted_filename, target_file)

with open(target_file, 'wb') as decrypt_file:
    decrypt_file.write(decrypted)