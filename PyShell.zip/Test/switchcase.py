def foo(var):
    return {
        'a': 1,
        'b': 2,
        'c': 3,
        }.get(var,'error')
    
print(foo('a'))