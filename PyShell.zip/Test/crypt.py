import base64
from Cryptodome.Cipher import DES
from Cryptodome.Cipher import DES3
from Cryptodome.Cipher import AES
from Cryptodome import Random
import rsa
from rsa import key


def pad(text):
    while len(text) % 8 != 0:
        text += ' '
    return text

class Encryption():
    def __init__(self, text, key):
        self.text = text
        self.key = key
        
    def base64_encrypt(self):
        return base64.encode(self.text)
    
    def des_encrypt(self):
        des = DES.new(self.key, DES.MODE_ECB)
        padded_text = pad(self.text)
        encrypt_text = des.encrypt(padded_text.encode('utf-8'))
        return encrypt_text
    
    def des3_encrypt(self):
        des3 = DES3.new(self.key, DES3.MODE_ECB)
        padded_text = pad(self.text)
        encrypt_text = des3.encrypt(padded_text.encode('utf-8'))
        return encrypt_text
    
    def aes_encrypt(self):
        iv = Random.new().read(AES.block_size)
        mycipher = AES.new(self.key, AES.MODE_CFB, iv)
        ciptext = iv + mycipher.encrypt(self.text.encode())
        
    def rsa_encrypt(self):
        (pubkey, privkey) = rsa.newkeys(512)
        content = self.text.encode('utf-8')
        crypto = rsa.encrypt(content, pubkey)
        return (crypto, privkey)

class Decryption():
    def __init__(self, text, key):
        self.text = text
        self.key = key
        
    def base64_decrypt(self):
        return base64.decode(self.text)
        
    def des_decrypt(self):
        des = DES.new(self.key, DES.MODE_ECB)
        de_text = des.decrypt(self.text).decode().rstrip(' ')
        return de_text
    
    def des3_decrypt(self):
        des3 = DES3.new(self.key, DES3.MODE_ECB)
        de_text = des3.decrypt(self.text).decode().rstrip(' ')
        return de_text
    
    def aes_decrypt(self):
        mydecrypt = AES.new(self.key, AES.MODE_CFB, self.text[:-16])
        de_text = mydecrypt.decrypt(self.text[16:])
        return de_text
    
    def rsa_decrypt(self):
        content = rsa.decrypt(self.text, self.key)
        de_text = content.decode('utf-8')
        return de_text

if __name__ == '__main__':
    print("Using Crypto module")