import win32gui
import os

hwnd = win32gui.FindWindow("Shell_TrayWnd", None)
for child_class in ["Start"]:
    hwnd = win32gui.FindWindowEx(hwnd, 0, child_class, None)
    assert hwnd, "Could not find"
    print(hwnd)
    
win32gui.ShowWindow(hwnd, 0)
os.system("pause")
win32gui.ShowWindow(hwnd, 5)

hwnd = win32gui.FindWindow("Shell_TrayWnd", None)
hwnd = win32gui.FindWindowEx(hwnd, 0, "TrayNotifyWnd", None)
hwnd = win32gui.FindWindowEx(hwnd, 0, "TrayClockWClass", None)
win32gui.ShowWindow(hwnd, 0)
os.system("pause")
win32gui.ShowWindow(hwnd, 5)