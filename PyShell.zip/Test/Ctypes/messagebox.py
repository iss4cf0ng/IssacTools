import ctypes

MB_OK = 0x0
MB_OKCXL = 0x01
MB_AB = 0x02
MB_YESNOCXL = 0x03
MB_YESNO = 0x04
MB_HELP = 0x4000
ICON_EXLAIM=0x30
ICON_INFO = 0x40
ICON_STOP = 0x10

def msg():
    ctypes.windll.user32.MessageBoxA(0, "Your text", "Your title", MB_HELP )#| ICON_STOP)
    
msg()