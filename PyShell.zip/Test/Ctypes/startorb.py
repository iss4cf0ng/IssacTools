import win32gui

hwnd = win32gui.FindWindow("Shell_TrayWnd", None)
for child_class in ["Start"]:
    hwnd = win32gui.FindWindowEx(hwnd, 0, child_class, None)
    assert hwnd, "Could not find"
    print(hwnd)
    
win32gui.ShowWindow(hwnd, 0)
x = input()
win32gui.ShowWindow(hwnd, 5)