# PyShell
大一計程 Final Project

## Description
Reverse Shell木馬  
當時四個人只有我一個在寫     
在沒有經驗的情況下寫出來的東西  
BUG都還沒改好就交上去了  
還有一些功能也沒了後續  
有些地方還寫得很糞  
不過偷密碼之類的還是能用  
之後再改吧...
